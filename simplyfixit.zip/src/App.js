import { Route, Routes } from 'react-router-dom';
import './App.css';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import Homepage from './pages/Homepage';
import Services from './pages/Services/Services';

function App() {
  return (
    <>
      {/* <Navbar /> */}

      <Routes>
        <Route exact path="/" element={<Homepage />} />
        <Route exact path="/services" element={<Services />} />
      </Routes>

      <Footer />
    </>
  );
}

export default App;
